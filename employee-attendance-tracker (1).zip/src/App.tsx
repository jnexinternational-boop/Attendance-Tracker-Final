import React, { useState, useEffect, useCallback } from 'react';
import { Employee, EmployeeStatusInfo, AttendanceRecord, PunchPayload } from './types';
import {
  fetchSheetData,
  punchAttendance,
  getCurrentDateString,
  getCurrentTimeString,
  calculateDurationString,
} from './services/sheetService';
import { Header } from './components/Header';
import { StatsBar } from './components/StatsBar';
import { StaffDirectory } from './components/StaffDirectory';
import { PunchConfirmationModal } from './components/PunchConfirmationModal';
import { AttendanceLogDrawer } from './components/AttendanceLogDrawer';
import { playPunchSound } from './utils/audio';
import { AlertCircle, CheckCircle2, RefreshCw, Database, ShieldCheck } from 'lucide-react';

export default function App() {
  // Application Data States (Fetched directly from Google Sheet, zero localStorage for attendance)
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [activeStatuses, setActiveStatuses] = useState<Record<string, EmployeeStatusInfo>>({});
  const [logs, setLogs] = useState<AttendanceRecord[]>([]);
  const [spreadsheetName, setSpreadsheetName] = useState<string>('Employee-Attendance-Register');

  // Network & UI States
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [scriptUrl, setScriptUrl] = useState<string>(
    import.meta.env.VITE_APPS_SCRIPT_URL ||
      'https://script.google.com/macros/s/AKfycbxva8BxJyPZXkpAfx46FGdhQzzddDoL-egUxI5GWbsW_Hs_kwqVBr5U_STQQvf9yCvN/exec'
  );
  const [selectedFilter, setSelectedFilter] = useState<'ALL' | 'IN' | 'OUT'>('ALL');

  // Modal & Drawer States
  const [isPunchModalOpen, setIsPunchModalOpen] = useState(false);
  const [isLogDrawerOpen, setIsLogDrawerOpen] = useState(false);

  // Selected Employee for Punching
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);
  const [selectedStatus, setSelectedStatus] = useState<EmployeeStatusInfo | null>(null);
  const [isPunchingEmployee, setIsPunchingEmployee] = useState<string | null>(null);

  // Toast Feedback State
  const [toast, setToast] = useState<{ type: 'success' | 'error' | 'info'; message: string } | null>(null);

  const showToast = useCallback((message: string, type: 'success' | 'error' | 'info' = 'info') => {
    setToast({ message, type });
    const timer = setTimeout(() => {
      setToast(null);
    }, 4000);
    return () => clearTimeout(timer);
  }, []);

  // Fetch Data directly from Google Apps Script Web App
  const loadData = useCallback(async (customUrl?: string, isSilent = false) => {
    const targetUrl = customUrl !== undefined ? customUrl : scriptUrl;
    if (!isSilent) setIsRefreshing(true);
    setError(null);

    try {
      const result = await fetchSheetData(targetUrl);
      if (result.success) {
        setEmployees(result.employees || []);
        setActiveStatuses(result.activeStatuses || {});
        setLogs(result.logs || []);
        if (result.spreadsheetName) {
          setSpreadsheetName(result.spreadsheetName);
        }
      } else {
        throw new Error(result.error || 'Failed to fetch data from sheet');
      }
    } catch (err: any) {
      console.error('Error loading sheet data:', err);
      setError(err.message || 'Unable to connect to Google Sheet');
      // If error occurred with custom URL, fallback to demo data
      if (targetUrl) {
        try {
          const fallback = await fetchSheetData('');
          setEmployees(fallback.employees);
          setActiveStatuses(fallback.activeStatuses);
          setLogs(fallback.logs);
        } catch {}
      }
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  }, [scriptUrl]);

  // Initial Load & Periodic Background Sync
  useEffect(() => {
    loadData(scriptUrl);

    // Auto sync every 45 seconds to keep all devices up-to-date with the Google Sheet
    const interval = setInterval(() => {
      loadData(scriptUrl, true);
    }, 45000);

    return () => clearInterval(interval);
  }, [loadData, scriptUrl]);

  // Handle Punch In / Out selection
  const handleSelectPunch = (employee: Employee, statusInfo: EmployeeStatusInfo) => {
    setSelectedEmployee(employee);
    setSelectedStatus(statusInfo);
    setIsPunchModalOpen(true);
  };

  // Execute Punch Action
  const handleConfirmPunch = async (
    employee: Employee,
    isClockIn: boolean,
    customTime?: string
  ) => {
    const punchTime = customTime || getCurrentTimeString();
    const punchDate = getCurrentDateString();
    const action = isClockIn ? 'IN' : 'OUT';

    setIsPunchingEmployee(employee.name);

    let timeInVal = isClockIn ? punchTime : (selectedStatus?.lastTimeIn || '');
    let timeOutVal = isClockIn ? '' : punchTime;
    let hoursWorkedVal = '';

    if (!isClockIn && selectedStatus?.lastTimeIn) {
      hoursWorkedVal = calculateDurationString(selectedStatus.lastTimeIn, punchTime);
    }

    const payload: PunchPayload = {
      name: employee.name,
      action,
      date: punchDate,
      time: punchTime,
      timeIn: timeInVal,
      timeOut: timeOutVal,
      hoursWorked: hoursWorkedVal,
    };

    try {
      const res = await punchAttendance(payload, scriptUrl);
      if (res.success) {
        playPunchSound(action);
        showToast(
          isClockIn
            ? `Clocked In: ${employee.name} at ${punchTime}`
            : `Clocked Out: ${employee.name} (${hoursWorkedVal || 'Completed'})`,
          'success'
        );

        // Optimistically update status on client while Google Sheet updates
        setActiveStatuses((prev) => ({
          ...prev,
          [employee.name]: {
            status: action,
            lastPunchTime: punchTime,
            lastTimeIn: isClockIn ? punchTime : (selectedStatus?.lastTimeIn || ''),
            lastTimeOut: isClockIn ? '' : punchTime,
            lastDate: punchDate,
            hoursWorked: hoursWorkedVal,
          },
        }));

        // Re-fetch from Google Sheet after 1.5s to ensure full sync
        setTimeout(() => {
          loadData(scriptUrl, true);
        }, 1600);
      } else {
        showToast(res.error || 'Punch request failed', 'error');
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to submit punch', 'error');
    } finally {
      setIsPunchingEmployee(null);
    }
  };

  // Save new script URL from setup modal
  const handleSaveScriptUrl = async (newUrl: string): Promise<boolean> => {
    try {
      const result = await fetchSheetData(newUrl);
      if (result.success && Array.isArray(result.employees)) {
        setScriptUrl(newUrl);
        setEmployees(result.employees);
        setActiveStatuses(result.activeStatuses || {});
        setLogs(result.logs || []);
        if (result.spreadsheetName) setSpreadsheetName(result.spreadsheetName);
        showToast('Successfully connected to Google Sheet!', 'success');
        return true;
      }
      return false;
    } catch (err) {
      console.error(err);
      return false;
    }
  };

  // Metrics calculation
  const totalEmployees = employees.length;
  const clockedInCount = Object.values(activeStatuses).filter((s) => s.status === 'IN').length;
  const clockedOutCount = Math.max(0, totalEmployees - clockedInCount);
  const todayStr = getCurrentDateString();
  const todayPunchesCount = logs.filter((l) => l.date === todayStr || !l.date).length;
  const isConnected = Boolean(scriptUrl && scriptUrl.trim().length > 10 && !error);

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      
      {/* App Header */}
      <Header
        spreadsheetName={spreadsheetName}
        isConnected={isConnected}
        isRefreshing={isRefreshing}
        onRefresh={() => loadData(scriptUrl)}
        onOpenLogs={() => setIsLogDrawerOpen(true)}
      />

      {/* Main Content Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        
        {/* Error notification if any */}
        {error && (
          <div className="mb-6 p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{error}</span>
            </div>
            <button
              onClick={() => loadData(scriptUrl)}
              className="font-bold underline ml-3"
            >
              Retry Connection
            </button>
          </div>
        )}

        {/* Attendance Stats Bar */}
        <StatsBar
          totalEmployees={totalEmployees}
          clockedInCount={clockedInCount}
          clockedOutCount={clockedOutCount}
          todayPunchesCount={todayPunchesCount}
          selectedFilter={selectedFilter}
          onFilterChange={setSelectedFilter}
        />

        {/* Staff Directory & Punch Register */}
        {isLoading ? (
          <div className="bg-white rounded-2xl border border-slate-200 p-16 text-center shadow-sm">
            <div className="w-10 h-10 border-3 border-indigo-600 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
            <h3 className="font-bold text-slate-800 text-base">Loading Roster &amp; Statuses</h3>
            <p className="text-xs text-slate-500 mt-1">
              Fetching dynamic employee records live from Google Sheet...
            </p>
          </div>
        ) : (
          <StaffDirectory
            employees={employees}
            activeStatuses={activeStatuses}
            selectedFilter={selectedFilter}
            onFilterChange={setSelectedFilter}
            onSelectPunch={handleSelectPunch}
            isPunchingEmployee={isPunchingEmployee}
          />
        )}

      </main>

      {/* Footer Info */}
      <footer className="mt-auto border-t border-slate-200 bg-white/80 py-4 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Zero-login kiosk mode • All statuses queried directly from Google Sheet</span>
          </div>
          <div className="text-slate-400">
            <span>React + Vite + Tailwind CSS</span>
          </div>
        </div>
      </footer>

      {/* Confirmation Punch Modal */}
      <PunchConfirmationModal
        employee={selectedEmployee}
        statusInfo={selectedStatus}
        isOpen={isPunchModalOpen}
        onClose={() => {
          setIsPunchModalOpen(false);
          setSelectedEmployee(null);
          setSelectedStatus(null);
        }}
        onConfirm={handleConfirmPunch}
      />

      {/* Attendance Log Drawer */}
      <AttendanceLogDrawer
        logs={logs}
        isOpen={isLogDrawerOpen}
        onClose={() => setIsLogDrawerOpen(false)}
        onRefresh={() => loadData(scriptUrl)}
        isRefreshing={isRefreshing}
        spreadsheetName={spreadsheetName}
      />

      {/* Toast Notification */}
      {toast && (
        <div className="fixed bottom-5 right-5 z-50 animate-in fade-in slide-in-from-bottom-3 duration-200">
          <div
            className={`px-4 py-3 rounded-xl shadow-lg border text-xs font-semibold flex items-center gap-2.5 ${
              toast.type === 'success'
                ? 'bg-slate-900 text-emerald-300 border-slate-800'
                : toast.type === 'error'
                ? 'bg-rose-950 text-rose-200 border-rose-800'
                : 'bg-slate-900 text-white border-slate-800'
            }`}
          >
            {toast.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-400" />
            )}
            <span>{toast.message}</span>
          </div>
        </div>
      )}

    </div>
  );
}
