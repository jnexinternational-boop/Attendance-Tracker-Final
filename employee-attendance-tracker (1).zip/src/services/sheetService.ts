import { Employee, EmployeeStatusInfo, AttendanceRecord, SheetApiResponse, PunchPayload, PunchResult } from '../types';

/**
 * Calculates duration between two time strings (e.g., "09:00 AM" and "05:30 PM")
 */
export function calculateDurationString(inStr: string, outStr: string): string {
  try {
    const parseTime = (str: string): number | null => {
      const match = str.match(/(\d+):(\d+)(?::(\d+))?\s*(AM|PM)?/i);
      if (!match) return null;
      let hours = parseInt(match[1], 10);
      const minutes = parseInt(match[2], 10);
      const ampm = match[4];
      if (ampm) {
        const upper = ampm.toUpperCase();
        if (upper === 'PM' && hours < 12) hours += 12;
        if (upper === 'AM' && hours === 12) hours = 0;
      }
      return hours * 60 + minutes;
    };

    const inMinutes = parseTime(inStr);
    const outMinutes = parseTime(outStr);

    if (inMinutes === null || outMinutes === null) return '0.00 hrs';

    let diffMinutes = outMinutes - inMinutes;
    if (diffMinutes < 0) {
      // Overnight shift crossed midnight
      diffMinutes += 24 * 60;
    }

    const hours = Math.floor(diffMinutes / 60);
    const mins = diffMinutes % 60;
    const decimalHours = (diffMinutes / 60).toFixed(2);

    return `${decimalHours} hrs (${hours}h ${mins}m)`;
  } catch {
    return '0.00 hrs';
  }
}

/**
 * Formats current date as YYYY-MM-DD
 */
export function getCurrentDateString(): string {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * Formats current time as "09:15 AM"
 */
export function getCurrentTimeString(): string {
  const d = new Date();
  return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true });
}

export const DEFAULT_APPS_SCRIPT_URL =
  'https://script.google.com/macros/s/AKfycbxva8BxJyPZXkpAfx46FGdhQzzddDoL-egUxI5GWbsW_Hs_kwqVBr5U_STQQvf9yCvN/exec';

// In-memory simulation store used ONLY when no Google Script URL is provided yet.
// No localStorage is used for attendance state per strict requirements.
let simulatedEmployees: Employee[] = [
  { name: 'Alex Morgan', avatarColor: '#4f46e5' },
  { name: 'David Kim', avatarColor: '#0ea5e9' },
  { name: 'Elena Rostova', avatarColor: '#10b981' },
  { name: 'Marcus Chen', avatarColor: '#f59e0b' },
  { name: 'Sophia Taylor', avatarColor: '#ec4899' },
  { name: 'James Wilson', avatarColor: '#8b5cf6' }
];

let simulatedLogs: AttendanceRecord[] = [
  {
    name: 'David Kim',
    date: getCurrentDateString(),
    time: '08:30 AM',
    timeIn: '08:30 AM',
    timeOut: '',
    hoursWorked: ''
  },
  {
    name: 'Elena Rostova',
    date: getCurrentDateString(),
    time: '08:45 AM',
    timeIn: '08:45 AM',
    timeOut: '',
    hoursWorked: ''
  },
  {
    name: 'Sophia Taylor',
    date: getCurrentDateString(),
    time: '09:00 AM',
    timeIn: '09:00 AM',
    timeOut: '',
    hoursWorked: ''
  }
];

/**
 * Fetches attendance data live via doGet() from Google Apps Script Web App.
 * If no URL is provided, utilizes dynamic simulation data for instant out-of-the-box preview.
 */
export async function fetchSheetData(scriptUrl?: string): Promise<SheetApiResponse> {
  const targetUrl = scriptUrl || import.meta.env.VITE_APPS_SCRIPT_URL || DEFAULT_APPS_SCRIPT_URL;

  if (targetUrl && targetUrl.trim().length > 10) {
    try {
      // Append cache-buster to ensure device-agnostic, fresh sheet reads on every pull
      const url = new URL(targetUrl.trim());
      url.searchParams.set('_t', Date.now().toString());

      const response = await fetch(url.toString(), {
        method: 'GET',
        headers: {
          'Accept': 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error(`HTTP Error ${response.status}: ${response.statusText}`);
      }

      const data: SheetApiResponse = await response.json();
      return data;
    } catch (err: any) {
      console.warn('Error fetching live data from Google Sheet:', err);
      throw new Error(`Failed to load from Google Sheet: ${err.message || err}`);
    }
  }

  // Fallback to in-memory live simulation (zero localStorage)
  // Computes real-time status from simulated attendance logs
  const activeStatuses: Record<string, EmployeeStatusInfo> = {};

  for (const emp of simulatedEmployees) {
    activeStatuses[emp.name] = {
      status: 'OUT',
      lastPunchTime: '',
      lastTimeIn: '',
      lastTimeOut: '',
      lastDate: '',
      hoursWorked: ''
    };
  }

  for (const log of simulatedLogs) {
    if (log.timeIn && !log.timeOut) {
      activeStatuses[log.name] = {
        status: 'IN',
        lastPunchTime: log.time,
        lastTimeIn: log.timeIn,
        lastTimeOut: '',
        lastDate: log.date,
        hoursWorked: ''
      };
    } else if (log.timeOut) {
      activeStatuses[log.name] = {
        status: 'OUT',
        lastPunchTime: log.time,
        lastTimeIn: log.timeIn,
        lastTimeOut: log.timeOut,
        lastDate: log.date,
        hoursWorked: log.hoursWorked
      };
    }
  }

  return {
    success: true,
    spreadsheetName: 'Employee-Attendance-Register (Demo Mode)',
    employees: [...simulatedEmployees],
    activeStatuses,
    logs: [...simulatedLogs].reverse(),
    totalLogs: simulatedLogs.length,
    serverTime: new Date().toISOString()
  };
}

/**
 * Punches Clock In or Clock Out.
 * Uses URLSearchParams with Content-Type: application/x-www-form-urlencoded and mode: 'no-cors'
 * to avoid browser preflight OPTIONS blocks as strictly mandated.
 */
export async function punchAttendance(
  payload: PunchPayload,
  scriptUrl?: string
): Promise<PunchResult> {
  const targetUrl = scriptUrl || import.meta.env.VITE_APPS_SCRIPT_URL || DEFAULT_APPS_SCRIPT_URL;

  if (targetUrl && targetUrl.trim().length > 10) {
    try {
      const params = new URLSearchParams();
      params.append('name', payload.name);
      params.append('action', payload.action);
      params.append('date', payload.date);
      params.append('time', payload.time);

      if (payload.action === 'IN') {
        params.append('timeIn', payload.timeIn || payload.time);
        params.append('timeOut', '');
        params.append('hoursWorked', '');
      } else {
        params.append('timeIn', payload.timeIn || '');
        params.append('timeOut', payload.timeOut || payload.time);
        params.append('hoursWorked', payload.hoursWorked || '');
      }

      // STRICT REQUIREMENT:
      // Send POST requests using URLSearchParams with
      // Content-Type: application/x-www-form-urlencoded and mode: 'no-cors'
      await fetch(targetUrl.trim(), {
        method: 'POST',
        mode: 'no-cors',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: params.toString()
      });

      return {
        success: true,
        message: `Successfully clocked ${payload.action} for ${payload.name}`
      };
    } catch (err: any) {
      console.error('Punch request failed:', err);
      return {
        success: false,
        error: `Punch request failed: ${err.message || 'Network error'}`
      };
    }
  }

  // Simulated punch in memory (zero localStorage)
  if (payload.action === 'IN') {
    simulatedLogs.push({
      name: payload.name,
      date: payload.date,
      time: payload.time,
      timeIn: payload.timeIn || payload.time,
      timeOut: '',
      hoursWorked: ''
    });
  } else {
    // Clocking out: find matching open log or append completed log
    const openLog = [...simulatedLogs].reverse().find(l => l.name === payload.name && l.timeIn && !l.timeOut);
    if (openLog) {
      openLog.timeOut = payload.timeOut || payload.time;
      openLog.time = payload.time;
      openLog.hoursWorked = payload.hoursWorked || calculateDurationString(openLog.timeIn, payload.timeOut || payload.time);
    } else {
      simulatedLogs.push({
        name: payload.name,
        date: payload.date,
        time: payload.time,
        timeIn: payload.timeIn || '',
        timeOut: payload.timeOut || payload.time,
        hoursWorked: payload.hoursWorked || ''
      });
    }
  }

  return {
    success: true,
    message: `[Demo] Clocked ${payload.action} for ${payload.name}`
  };
}
