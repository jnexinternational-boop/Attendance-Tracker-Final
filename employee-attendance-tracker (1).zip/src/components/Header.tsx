import React, { useState, useEffect } from 'react';
import { Clock, RefreshCw, Database, ExternalLink, Sparkles, CheckCircle2, AlertCircle } from 'lucide-react';

interface HeaderProps {
  spreadsheetName?: string;
  isConnected: boolean;
  isRefreshing: boolean;
  onRefresh: () => void;
  onOpenLogs: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  spreadsheetName,
  isConnected,
  isRefreshing,
  onRefresh,
  onOpenLogs,
}) => {
  const [currentTime, setCurrentTime] = useState<string>('');
  const [currentDate, setCurrentDate] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString([], {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
          hour12: true,
        })
      );
      setCurrentDate(
        now.toLocaleDateString([], {
          weekday: 'short',
          month: 'short',
          day: 'numeric',
          year: 'numeric',
        })
      );
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <header className="bg-slate-900 border-b border-slate-800 text-white sticky top-0 z-30 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex flex-col sm:flex-row items-center justify-between gap-4">
        
        {/* Left: Branding & Connection Status */}
        <div className="flex items-center gap-3 w-full sm:w-auto justify-between sm:justify-start">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center shadow-lg shadow-indigo-600/30 text-white font-bold">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-semibold tracking-tight text-white leading-tight">
                  Attendance Tracker
                </h1>
                <span className="text-[10px] font-medium uppercase tracking-wider px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  Zero-Login
                </span>
              </div>
              <p className="text-xs text-slate-400 truncate max-w-[200px] sm:max-w-xs">
                {spreadsheetName || 'Employee-Attendance-Register'}
              </p>
            </div>
          </div>

          <div className="sm:hidden flex items-center gap-1.5">
            <button
              onClick={onRefresh}
              disabled={isRefreshing}
              className="p-2 rounded-lg bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition"
              title="Refresh roster and statuses"
            >
              <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin text-indigo-400' : ''}`} />
            </button>
          </div>
        </div>

        {/* Center: Live Digital Clock */}
        <div className="flex items-center gap-3 bg-slate-950/60 border border-slate-800/80 px-4 py-1.5 rounded-full shadow-inner">
          <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <div className="text-center font-mono">
            <span className="text-base sm:text-lg font-semibold tracking-wider text-emerald-300">
              {currentTime || '--:--:-- --'}
            </span>
            <span className="mx-2 text-slate-600 hidden sm:inline">|</span>
            <span className="text-xs text-slate-400 font-sans hidden sm:inline">
              {currentDate}
            </span>
          </div>
        </div>

        {/* Right: Actions */}
        <div className="flex items-center gap-2.5 w-full sm:w-auto justify-end">
          <div className="flex items-center gap-1.5 text-xs text-emerald-300 bg-emerald-950/50 border border-emerald-800/60 px-2.5 py-1.5 rounded-lg select-none">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="font-medium">Sheet Synced</span>
          </div>

          <button
            onClick={onOpenLogs}
            className="text-xs font-medium px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700/70 transition flex items-center gap-1.5"
          >
            <Database className="w-3.5 h-3.5 text-indigo-400" />
            <span>Attendance Log</span>
          </button>

          <button
            onClick={onRefresh}
            disabled={isRefreshing}
            className="hidden sm:flex items-center gap-1.5 text-xs font-medium px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition"
            title="Refresh roster and statuses"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-indigo-400' : ''}`} />
            <span>Refresh</span>
          </button>
        </div>

      </div>
    </header>
  );
};
