import React, { useState, useEffect } from 'react';
import { Employee, EmployeeStatusInfo } from '../types';
import { calculateDurationString, getCurrentTimeString } from '../services/sheetService';
import { Search, LogIn, LogOut, CheckCircle, Clock, Grid, List, Sparkles } from 'lucide-react';

interface StaffDirectoryProps {
  employees: Employee[];
  activeStatuses: Record<string, EmployeeStatusInfo>;
  selectedFilter: 'ALL' | 'IN' | 'OUT';
  onFilterChange: (filter: 'ALL' | 'IN' | 'OUT') => void;
  onSelectPunch: (employee: Employee, currentStatus: EmployeeStatusInfo) => void;
  isPunchingEmployee: string | null;
}

export const StaffDirectory: React.FC<StaffDirectoryProps> = ({
  employees,
  activeStatuses,
  selectedFilter,
  onFilterChange,
  onSelectPunch,
  isPunchingEmployee,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  // State to force re-render every minute to update elapsed time for clocked-in staff
  const [, setMinuteTicker] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setMinuteTicker((prev) => prev + 1);
    }, 30000);
    return () => clearInterval(timer);
  }, []);

  // Filter employees
  const filteredEmployees = employees.filter((emp) => {
    const matchesSearch = emp.name.toLowerCase().includes(searchQuery.toLowerCase());
    const status = activeStatuses[emp.name]?.status || 'OUT';

    if (!matchesSearch) return false;
    if (selectedFilter === 'IN') return status === 'IN';
    if (selectedFilter === 'OUT') return status === 'OUT';
    return true;
  });

  // Calculate initials from name
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((part) => part[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <div className="space-y-4">
      {/* Controls Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white p-3.5 rounded-xl border border-slate-200 shadow-sm">
        
        {/* Search Input */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search employee by name..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition text-slate-800 placeholder-slate-400"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600 font-medium"
            >
              Clear
            </button>
          )}
        </div>

        {/* Filter Pills & View Mode */}
        <div className="flex items-center justify-between sm:justify-end gap-2">
          <div className="flex items-center bg-slate-100 p-1 rounded-lg border border-slate-200/80 text-xs font-medium">
            <button
              onClick={() => onFilterChange('ALL')}
              className={`px-3 py-1.5 rounded-md transition ${
                selectedFilter === 'ALL'
                  ? 'bg-white text-slate-900 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All ({employees.length})
            </button>
            <button
              onClick={() => onFilterChange('IN')}
              className={`px-3 py-1.5 rounded-md transition flex items-center gap-1.5 ${
                selectedFilter === 'IN'
                  ? 'bg-emerald-600 text-white shadow-xs font-semibold'
                  : 'text-emerald-700 hover:text-emerald-900'
              }`}
            >
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
              In
            </button>
            <button
              onClick={() => onFilterChange('OUT')}
              className={`px-3 py-1.5 rounded-md transition ${
                selectedFilter === 'OUT'
                  ? 'bg-slate-700 text-white shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Out
            </button>
          </div>

          <div className="hidden sm:flex items-center bg-slate-100 p-1 rounded-lg border border-slate-200/80">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-1.5 rounded-md transition ${
                viewMode === 'grid'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
              title="Grid View"
            >
              <Grid className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-1.5 rounded-md transition ${
                viewMode === 'list'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
              title="List View"
            >
              <List className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Directory Grid View */}
      {filteredEmployees.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 p-12 text-center shadow-sm">
          <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto mb-3">
            <Search className="w-6 h-6" />
          </div>
          <h3 className="text-base font-semibold text-slate-800">No employees found</h3>
          <p className="text-sm text-slate-500 max-w-sm mx-auto mt-1">
            {searchQuery
              ? `No staff matching "${searchQuery}". Check the spelling or reset search.`
              : 'The roster in the Google Sheet "Employees" tab appears to be empty.'}
          </p>
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="mt-4 px-4 py-2 text-xs font-medium rounded-lg bg-indigo-50 text-indigo-600 hover:bg-indigo-100 transition"
            >
              Clear Filter
            </button>
          )}
        </div>
      ) : viewMode === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredEmployees.map((emp) => {
            const statusInfo = activeStatuses[emp.name] || {
              status: 'OUT',
              lastPunchTime: '',
              lastTimeIn: '',
              lastTimeOut: '',
              lastDate: '',
              hoursWorked: '',
            };
            const isClockedIn = statusInfo.status === 'IN';
            const isProcessing = isPunchingEmployee === emp.name;

            // Compute elapsed shift duration if currently in
            const elapsed = isClockedIn && statusInfo.lastTimeIn
              ? calculateDurationString(statusInfo.lastTimeIn, getCurrentTimeString())
              : null;

            return (
              <div
                key={emp.name}
                className={`group relative bg-white rounded-2xl border transition-all duration-200 overflow-hidden shadow-xs hover:shadow-md ${
                  isClockedIn
                    ? 'border-emerald-200 ring-1 ring-emerald-500/20 hover:border-emerald-400'
                    : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                {/* Status indicator bar on top */}
                <div
                  className={`h-1.5 w-full transition-colors ${
                    isClockedIn ? 'bg-emerald-500' : 'bg-slate-200'
                  }`}
                />

                <div className="p-5">
                  {/* Avatar & Header */}
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3.5">
                      <div
                        className="w-12 h-12 rounded-xl flex items-center justify-center font-bold text-white text-base shadow-sm ring-2 ring-white select-none transition-transform group-hover:scale-105"
                        style={{ backgroundColor: emp.avatarColor || '#4f46e5' }}
                      >
                        {getInitials(emp.name)}
                      </div>
                      <div>
                        <h3 className="font-semibold text-slate-900 text-base leading-snug group-hover:text-indigo-600 transition">
                          {emp.name}
                        </h3>
                        <p className="text-xs text-slate-500 flex items-center gap-1 mt-0.5">
                          <span
                            className="inline-block w-2 h-2 rounded-full"
                            style={{ backgroundColor: emp.avatarColor || '#4f46e5' }}
                          />
                          <span>ID: {emp.name.replace(/\s+/g, '-').toLowerCase()}</span>
                        </p>
                      </div>
                    </div>

                    {/* Status Pill */}
                    <span
                      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold tracking-wide uppercase transition ${
                        isClockedIn
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : 'bg-slate-100 text-slate-600 border border-slate-200'
                      }`}
                    >
                      <span
                        className={`w-1.5 h-1.5 rounded-full ${
                          isClockedIn ? 'bg-emerald-500 animate-pulse' : 'bg-slate-400'
                        }`}
                      />
                      {isClockedIn ? 'Clocked In' : 'Clocked Out'}
                    </span>
                  </div>

                  {/* Shift Status Details */}
                  <div className="mt-4 pt-3.5 border-t border-slate-100 text-xs text-slate-600 space-y-1.5 min-h-[52px]">
                    {isClockedIn ? (
                      <div>
                        <div className="flex items-center justify-between text-slate-700 font-medium">
                          <span className="flex items-center gap-1 text-emerald-700">
                            <Clock className="w-3.5 h-3.5" />
                            <span>In: {statusInfo.lastTimeIn}</span>
                          </span>
                          <span className="text-slate-500 font-mono text-[11px]">
                            {statusInfo.lastDate || 'Today'}
                          </span>
                        </div>
                        {elapsed && (
                          <div className="mt-1 text-slate-500 flex items-center justify-between">
                            <span>Time elapsed:</span>
                            <span className="font-semibold text-emerald-700 font-mono">
                              {elapsed}
                            </span>
                          </div>
                        )}
                      </div>
                    ) : (
                      <div>
                        <div className="flex items-center justify-between text-slate-500">
                          <span>Status:</span>
                          <span className="font-medium text-slate-700">Off Duty</span>
                        </div>
                        {statusInfo.lastTimeOut && (
                          <div className="mt-1 text-[11px] text-slate-500 flex items-center justify-between truncate">
                            <span>Last punch out:</span>
                            <span className="font-mono text-slate-600">
                              {statusInfo.lastTimeOut} ({statusInfo.hoursWorked || 'Done'})
                            </span>
                          </div>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Punch Action Button */}
                  <div className="mt-4 pt-2">
                    <button
                      onClick={() => onSelectPunch(emp, statusInfo)}
                      disabled={isProcessing}
                      className={`w-full py-2.5 px-4 rounded-xl text-sm font-semibold flex items-center justify-center gap-2 shadow-sm transition active:scale-[0.98] ${
                        isClockedIn
                          ? 'bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 hover:border-rose-300'
                          : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-600/20 hover:shadow-emerald-600/30'
                      }`}
                    >
                      {isProcessing ? (
                        <div className="w-5 h-5 border-2 border-current border-t-transparent rounded-full animate-spin" />
                      ) : isClockedIn ? (
                        <>
                          <LogOut className="w-4 h-4 text-rose-600" />
                          <span>Punch Out</span>
                        </>
                      ) : (
                        <>
                          <LogIn className="w-4 h-4 text-white" />
                          <span>Punch In</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* List Table View */
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600 uppercase tracking-wider">
                <tr>
                  <th className="py-3 px-4">Employee</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Time In</th>
                  <th className="py-3 px-4">Time Out</th>
                  <th className="py-3 px-4">Shift Duration</th>
                  <th className="py-3 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {filteredEmployees.map((emp) => {
                  const statusInfo = activeStatuses[emp.name] || {
                    status: 'OUT',
                    lastPunchTime: '',
                    lastTimeIn: '',
                    lastTimeOut: '',
                    lastDate: '',
                    hoursWorked: '',
                  };
                  const isClockedIn = statusInfo.status === 'IN';
                  const isProcessing = isPunchingEmployee === emp.name;
                  const elapsed = isClockedIn && statusInfo.lastTimeIn
                    ? calculateDurationString(statusInfo.lastTimeIn, getCurrentTimeString())
                    : null;

                  return (
                    <tr key={emp.name} className="hover:bg-slate-50/80 transition">
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-3">
                          <div
                            className="w-9 h-9 rounded-lg flex items-center justify-center font-bold text-white text-xs shadow-xs"
                            style={{ backgroundColor: emp.avatarColor || '#4f46e5' }}
                          >
                            {getInitials(emp.name)}
                          </div>
                          <div>
                            <div className="font-semibold text-slate-900">{emp.name}</div>
                            <div className="text-[11px] text-slate-400 font-mono">
                              {emp.avatarColor}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <span
                          className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold uppercase ${
                            isClockedIn
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-slate-100 text-slate-600'
                          }`}
                        >
                          <span
                            className={`w-1.5 h-1.5 rounded-full ${
                              isClockedIn ? 'bg-emerald-500 animate-pulse' : 'bg-slate-400'
                            }`}
                          />
                          {isClockedIn ? 'In' : 'Out'}
                        </span>
                      </td>
                      <td className="py-3 px-4 font-mono text-xs text-slate-700">
                        {statusInfo.lastTimeIn || '—'}
                      </td>
                      <td className="py-3 px-4 font-mono text-xs text-slate-700">
                        {statusInfo.lastTimeOut || '—'}
                      </td>
                      <td className="py-3 px-4 text-xs font-mono">
                        {isClockedIn ? (
                          <span className="text-emerald-700 font-semibold">{elapsed}</span>
                        ) : (
                          <span className="text-slate-500">{statusInfo.hoursWorked || '—'}</span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <button
                          onClick={() => onSelectPunch(emp, statusInfo)}
                          disabled={isProcessing}
                          className={`px-3 py-1.5 rounded-lg text-xs font-semibold inline-flex items-center gap-1.5 transition ${
                            isClockedIn
                              ? 'bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-200'
                              : 'bg-emerald-600 text-white hover:bg-emerald-500'
                          }`}
                        >
                          {isProcessing ? (
                            <div className="w-3.5 h-3.5 border-2 border-current border-t-transparent rounded-full animate-spin" />
                          ) : isClockedIn ? (
                            <>
                              <LogOut className="w-3.5 h-3.5" />
                              <span>Punch Out</span>
                            </>
                          ) : (
                            <>
                              <LogIn className="w-3.5 h-3.5" />
                              <span>Punch In</span>
                            </>
                          )}
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
