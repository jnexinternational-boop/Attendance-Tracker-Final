import React, { useState, useEffect } from 'react';
import { Employee, EmployeeStatusInfo } from '../types';
import { calculateDurationString, getCurrentDateString, getCurrentTimeString } from '../services/sheetService';
import { X, LogIn, LogOut, Clock, Calendar, Check, AlertCircle } from 'lucide-react';

interface PunchConfirmationModalProps {
  employee: Employee | null;
  statusInfo: EmployeeStatusInfo | null;
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (employee: Employee, isClockIn: boolean, customTime?: string) => Promise<void>;
}

export const PunchConfirmationModal: React.FC<PunchConfirmationModalProps> = ({
  employee,
  statusInfo,
  isOpen,
  onClose,
  onConfirm,
}) => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [liveTime, setLiveTime] = useState(getCurrentTimeString());
  const [currentDate] = useState(getCurrentDateString());

  useEffect(() => {
    if (!isOpen) return;
    const timer = setInterval(() => {
      setLiveTime(getCurrentTimeString());
    }, 1000);
    return () => clearInterval(timer);
  }, [isOpen]);

  if (!isOpen || !employee) return null;

  const isClockIn = (statusInfo?.status || 'OUT') === 'OUT';
  const initialTimeIn = statusInfo?.lastTimeIn || '';
  const calculatedDuration = !isClockIn && initialTimeIn
    ? calculateDurationString(initialTimeIn, liveTime)
    : null;

  const handleConfirm = async () => {
    try {
      setIsSubmitting(true);
      await onConfirm(employee, isClockIn, liveTime);
      onClose();
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const initials = employee.name
    .split(' ')
    .map((n) => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
      <div
        className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 overflow-hidden transform transition-all animate-in fade-in zoom-in-95 duration-150"
        role="dialog"
      >
        {/* Header */}
        <div className={`p-5 flex items-center justify-between border-b ${
          isClockIn ? 'bg-emerald-50/70 border-emerald-100' : 'bg-rose-50/70 border-rose-100'
        }`}>
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center text-white font-bold text-sm shadow-xs"
              style={{ backgroundColor: employee.avatarColor || '#4f46e5' }}
            >
              {initials}
            </div>
            <div>
              <h2 className="font-bold text-slate-900 text-lg leading-tight">
                {isClockIn ? 'Confirm Clock In' : 'Confirm Clock Out'}
              </h2>
              <p className="text-xs text-slate-600 font-medium">{employee.name}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            disabled={isSubmitting}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-white/80 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Content */}
        <div className="p-6 space-y-5">
          {/* Action Badge & Live Time Preview */}
          <div className="text-center py-4 px-3 rounded-xl bg-slate-50 border border-slate-200/80">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wider mb-2">
              {isClockIn ? (
                <span className="text-emerald-700 bg-emerald-100/80 px-2.5 py-0.5 rounded-full flex items-center gap-1.5">
                  <LogIn className="w-3.5 h-3.5" />
                  Clocking In
                </span>
              ) : (
                <span className="text-rose-700 bg-rose-100/80 px-2.5 py-0.5 rounded-full flex items-center gap-1.5">
                  <LogOut className="w-3.5 h-3.5" />
                  Clocking Out
                </span>
              )}
            </div>

            <div className="text-3xl font-mono font-bold text-slate-900 tracking-tight">
              {liveTime}
            </div>
            <div className="text-xs text-slate-500 mt-1 flex items-center justify-center gap-1.5 font-medium">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              <span>{currentDate}</span>
            </div>
          </div>

          {/* Details list */}
          <div className="space-y-2.5 text-xs text-slate-600 bg-slate-50/50 p-4 rounded-xl border border-slate-100">
            <div className="flex items-center justify-between">
              <span className="text-slate-500">Employee:</span>
              <span className="font-semibold text-slate-800">{employee.name}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-500">Punch Date:</span>
              <span className="font-mono text-slate-700">{currentDate}</span>
            </div>

            {isClockIn ? (
              <div className="flex items-center justify-between text-emerald-800">
                <span className="font-medium">Time In Recorded:</span>
                <span className="font-mono font-bold text-emerald-600">{liveTime}</span>
              </div>
            ) : (
              <>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Shift Started (Time In):</span>
                  <span className="font-mono text-slate-700">{initialTimeIn || 'Not recorded'}</span>
                </div>
                <div className="flex items-center justify-between text-rose-800">
                  <span className="font-medium">Time Out Recorded:</span>
                  <span className="font-mono font-bold text-rose-600">{liveTime}</span>
                </div>
                {calculatedDuration && (
                  <div className="pt-2 mt-2 border-t border-slate-200/80 flex items-center justify-between">
                    <span className="font-semibold text-slate-700">Calculated Hours:</span>
                    <span className="font-mono font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-200/60">
                      {calculatedDuration}
                    </span>
                  </div>
                )}
              </>
            )}
          </div>

          {/* Prompt compliance note */}
          <p className="text-[11px] text-slate-400 text-center leading-relaxed">
            {isClockIn
              ? 'This punch records Time In on the Google Sheet. Time Out and Hours Worked will remain open until clock out.'
              : 'This punch completes the active shift on the Google Sheet and records total duration.'}
          </p>
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-end gap-2.5">
          <button
            onClick={onClose}
            disabled={isSubmitting}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 hover:bg-slate-200/70 rounded-xl transition"
          >
            Cancel
          </button>
          <button
            onClick={handleConfirm}
            disabled={isSubmitting}
            className={`px-5 py-2 text-xs font-semibold text-white rounded-xl shadow-sm transition flex items-center gap-2 ${
              isClockIn
                ? 'bg-emerald-600 hover:bg-emerald-500 shadow-emerald-600/20'
                : 'bg-rose-600 hover:bg-rose-500 shadow-rose-600/20'
            }`}
          >
            {isSubmitting ? (
              <>
                <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span>Recording to Sheet...</span>
              </>
            ) : isClockIn ? (
              <>
                <Check className="w-4 h-4" />
                <span>Confirm Clock In</span>
              </>
            ) : (
              <>
                <Check className="w-4 h-4" />
                <span>Confirm Clock Out</span>
              </>
            )}
          </button>
        </div>

      </div>
    </div>
  );
};
