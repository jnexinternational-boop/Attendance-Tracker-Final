import React, { useState } from 'react';
import { AttendanceRecord } from '../types';
import { X, Search, FileSpreadsheet, Download, RefreshCw, Clock, ArrowRight } from 'lucide-react';

interface AttendanceLogDrawerProps {
  logs: AttendanceRecord[];
  isOpen: boolean;
  onClose: () => void;
  onRefresh: () => void;
  isRefreshing: boolean;
  spreadsheetName?: string;
}

export const AttendanceLogDrawer: React.FC<AttendanceLogDrawerProps> = ({
  logs,
  isOpen,
  onClose,
  onRefresh,
  isRefreshing,
  spreadsheetName,
}) => {
  const [filterQuery, setFilterQuery] = useState('');
  const [filterDate, setFilterDate] = useState<'all' | 'today'>('all');

  if (!isOpen) return null;

  const todayStr = new Date().toISOString().slice(0, 10);

  const filteredLogs = logs.filter((log) => {
    const matchesName = log.name.toLowerCase().includes(filterQuery.toLowerCase());
    const matchesDate = filterDate === 'all' || (log.date && log.date.includes(todayStr));
    return matchesName && matchesDate;
  });

  const exportCSV = () => {
    if (logs.length === 0) return;
    const headers = ['Name', 'Date', 'Time', 'Time In', 'Time Out', 'Hours Worked'];
    const rows = logs.map((l) => [
      `"${l.name}"`,
      `"${l.date}"`,
      `"${l.time}"`,
      `"${l.timeIn}"`,
      `"${l.timeOut}"`,
      `"${l.hoursWorked}"`,
    ]);

    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `Attendance_Log_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-950/60 backdrop-blur-xs">
      <div className="bg-white w-full max-w-2xl h-full shadow-2xl flex flex-col animate-in slide-in-from-right duration-200">
        
        {/* Drawer Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-xs">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-slate-900 text-base leading-tight">
                Attendance_Log Register
              </h2>
              <p className="text-xs text-slate-500">
                Direct log records from Google Sheet tab &quot;Attendance_Log&quot;
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onRefresh}
              disabled={isRefreshing}
              className="p-2 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-200 transition"
              title="Refresh logs from Google Sheet"
            >
              <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin text-indigo-600' : ''}`} />
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Toolbar */}
        <div className="p-4 border-b border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 bg-white">
          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Filter by employee name..."
              value={filterQuery}
              onChange={(e) => setFilterQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 text-slate-800"
            />
          </div>

          <div className="flex items-center justify-between w-full sm:w-auto gap-2">
            <div className="flex bg-slate-100 p-1 rounded-lg text-xs font-medium">
              <button
                onClick={() => setFilterDate('all')}
                className={`px-2.5 py-1 rounded-md transition ${
                  filterDate === 'all' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600'
                }`}
              >
                All ({logs.length})
              </button>
              <button
                onClick={() => setFilterDate('today')}
                className={`px-2.5 py-1 rounded-md transition ${
                  filterDate === 'today' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600'
                }`}
              >
                Today
              </button>
            </div>

            <button
              onClick={exportCSV}
              disabled={logs.length === 0}
              className="text-xs font-medium px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-700 flex items-center gap-1.5 transition"
            >
              <Download className="w-3.5 h-3.5 text-slate-500" />
              <span>Export CSV</span>
            </button>
          </div>
        </div>

        {/* Table Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5">
          {filteredLogs.length === 0 ? (
            <div className="py-16 text-center">
              <Clock className="w-10 h-10 text-slate-300 mx-auto mb-2" />
              <p className="text-sm font-medium text-slate-700">No attendance records found</p>
              <p className="text-xs text-slate-400 mt-0.5">
                {filterQuery
                  ? `No logs matching "${filterQuery}"`
                  : 'Punch logs recorded in the sheet will be listed here in real-time.'}
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredLogs.map((log, idx) => {
                const isShiftComplete = Boolean(log.timeOut);

                return (
                  <div
                    key={`${log.name}-${log.date}-${log.time}-${idx}`}
                    className="p-3.5 rounded-xl border border-slate-200 bg-white hover:border-indigo-200 transition shadow-xs"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-sm text-slate-900">{log.name}</span>
                        <span
                          className={`text-[10px] font-semibold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                            isShiftComplete
                              ? 'bg-slate-100 text-slate-600'
                              : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          }`}
                        >
                          {isShiftComplete ? 'Shift Finished' : 'Active Shift'}
                        </span>
                      </div>
                      <span className="text-xs font-mono text-slate-500">{log.date}</span>
                    </div>

                    <div className="grid grid-cols-3 gap-2 text-xs bg-slate-50 p-2.5 rounded-lg font-mono">
                      <div>
                        <span className="text-[10px] uppercase text-slate-400 font-sans block">Time In</span>
                        <span className="text-slate-800 font-semibold">{log.timeIn || '—'}</span>
                      </div>
                      <div>
                        <span className="text-[10px] uppercase text-slate-400 font-sans block">Time Out</span>
                        <span className="text-slate-800 font-semibold">{log.timeOut || 'In progress'}</span>
                      </div>
                      <div>
                        <span className="text-[10px] uppercase text-slate-400 font-sans block">Hours</span>
                        <span className="text-indigo-700 font-bold">{log.hoursWorked || 'Pending'}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 text-xs text-slate-500 flex items-center justify-between">
          <span>Synced live with Google Sheet</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-slate-800 text-white hover:bg-slate-700 font-medium transition"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
