import React from 'react';
import { Users, UserCheck, UserMinus, Activity } from 'lucide-react';

interface StatsBarProps {
  totalEmployees: number;
  clockedInCount: number;
  clockedOutCount: number;
  todayPunchesCount: number;
  selectedFilter: 'ALL' | 'IN' | 'OUT';
  onFilterChange: (filter: 'ALL' | 'IN' | 'OUT') => void;
}

export const StatsBar: React.FC<StatsBarProps> = ({
  totalEmployees,
  clockedInCount,
  clockedOutCount,
  todayPunchesCount,
  selectedFilter,
  onFilterChange,
}) => {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 my-6">
      
      {/* Total Staff Card */}
      <button
        onClick={() => onFilterChange('ALL')}
        className={`text-left p-4 rounded-xl border transition-all ${
          selectedFilter === 'ALL'
            ? 'bg-slate-900 border-indigo-500 shadow-md ring-1 ring-indigo-500/40'
            : 'bg-white hover:bg-slate-50 border-slate-200 shadow-sm'
        }`}
      >
        <div className="flex items-center justify-between">
          <span className={`text-xs font-semibold tracking-wide uppercase ${
            selectedFilter === 'ALL' ? 'text-indigo-300' : 'text-slate-500'
          }`}>
            Total Staff
          </span>
          <div className={`p-2 rounded-lg ${
            selectedFilter === 'ALL' ? 'bg-indigo-950 text-indigo-400' : 'bg-slate-100 text-slate-600'
          }`}>
            <Users className="w-4 h-4" />
          </div>
        </div>
        <div className="mt-2 flex items-baseline gap-2">
          <span className={`text-2xl sm:text-3xl font-bold font-mono ${
            selectedFilter === 'ALL' ? 'text-white' : 'text-slate-900'
          }`}>
            {totalEmployees}
          </span>
          <span className={`text-xs ${
            selectedFilter === 'ALL' ? 'text-slate-400' : 'text-slate-500'
          }`}>
            in roster
          </span>
        </div>
      </button>

      {/* Clocked In Card */}
      <button
        onClick={() => onFilterChange('IN')}
        className={`text-left p-4 rounded-xl border transition-all ${
          selectedFilter === 'IN'
            ? 'bg-emerald-950 border-emerald-500 shadow-md ring-1 ring-emerald-500/40 text-white'
            : 'bg-white hover:bg-emerald-50/40 border-slate-200 shadow-sm'
        }`}
      >
        <div className="flex items-center justify-between">
          <span className={`text-xs font-semibold tracking-wide uppercase ${
            selectedFilter === 'IN' ? 'text-emerald-300' : 'text-emerald-700'
          }`}>
            Clocked In Now
          </span>
          <div className={`p-2 rounded-lg ${
            selectedFilter === 'IN' ? 'bg-emerald-900 text-emerald-300' : 'bg-emerald-100 text-emerald-700'
          }`}>
            <UserCheck className="w-4 h-4" />
          </div>
        </div>
        <div className="mt-2 flex items-baseline gap-2">
          <span className={`text-2xl sm:text-3xl font-bold font-mono ${
            selectedFilter === 'IN' ? 'text-white' : 'text-emerald-600'
          }`}>
            {clockedInCount}
          </span>
          <span className={`text-xs ${
            selectedFilter === 'IN' ? 'text-emerald-200' : 'text-slate-500'
          }`}>
            active on shift
          </span>
        </div>
      </button>

      {/* Clocked Out Card */}
      <button
        onClick={() => onFilterChange('OUT')}
        className={`text-left p-4 rounded-xl border transition-all ${
          selectedFilter === 'OUT'
            ? 'bg-slate-900 border-slate-500 shadow-md ring-1 ring-slate-500/40 text-white'
            : 'bg-white hover:bg-slate-50 border-slate-200 shadow-sm'
        }`}
      >
        <div className="flex items-center justify-between">
          <span className={`text-xs font-semibold tracking-wide uppercase ${
            selectedFilter === 'OUT' ? 'text-slate-300' : 'text-slate-500'
          }`}>
            Clocked Out
          </span>
          <div className={`p-2 rounded-lg ${
            selectedFilter === 'OUT' ? 'bg-slate-800 text-slate-300' : 'bg-slate-100 text-slate-500'
          }`}>
            <UserMinus className="w-4 h-4" />
          </div>
        </div>
        <div className="mt-2 flex items-baseline gap-2">
          <span className={`text-2xl sm:text-3xl font-bold font-mono ${
            selectedFilter === 'OUT' ? 'text-white' : 'text-slate-700'
          }`}>
            {clockedOutCount}
          </span>
          <span className={`text-xs ${
            selectedFilter === 'OUT' ? 'text-slate-400' : 'text-slate-500'
          }`}>
            off duty
          </span>
        </div>
      </button>

      {/* Activity Count Card */}
      <div className="p-4 rounded-xl border border-slate-200 bg-white shadow-sm flex flex-col justify-between">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold tracking-wide uppercase text-slate-500">
            Punches Today
          </span>
          <div className="p-2 rounded-lg bg-indigo-50 text-indigo-600">
            <Activity className="w-4 h-4" />
          </div>
        </div>
        <div className="mt-2 flex items-baseline gap-2">
          <span className="text-2xl sm:text-3xl font-bold font-mono text-slate-900">
            {todayPunchesCount}
          </span>
          <span className="text-xs text-slate-500">
            recorded in sheet
          </span>
        </div>
      </div>

    </div>
  );
};
