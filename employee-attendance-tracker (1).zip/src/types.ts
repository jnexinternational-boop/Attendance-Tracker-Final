/**
 * Type definitions for Employee Attendance Tracker
 */

export interface Employee {
  name: string;
  avatarColor: string;
}

export type ClockStatus = 'IN' | 'OUT';

export interface EmployeeStatusInfo {
  status: ClockStatus;
  lastPunchTime: string;
  lastTimeIn: string;
  lastTimeOut: string;
  lastDate: string;
  hoursWorked: string;
  logRowIndex?: number;
}

export interface AttendanceRecord {
  rowIndex?: number;
  name: string;
  date: string;
  time: string;
  timeIn: string;
  timeOut: string;
  hoursWorked: string;
}

export interface SheetApiResponse {
  success: boolean;
  spreadsheetName?: string;
  employees: Employee[];
  activeStatuses: Record<string, EmployeeStatusInfo>;
  logs: AttendanceRecord[];
  totalLogs?: number;
  serverTime?: string;
  error?: string;
}

export interface PunchPayload {
  name: string;
  action: 'IN' | 'OUT';
  date: string;
  time: string;
  timeIn?: string;
  timeOut?: string;
  hoursWorked?: string;
}

export interface PunchResult {
  success: boolean;
  message?: string;
  error?: string;
}
