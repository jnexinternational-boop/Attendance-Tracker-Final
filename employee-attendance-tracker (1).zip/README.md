# ⏱️ Zero-Login Employee Attendance Tracker

A modern, device-agnostic, zero-login employee attendance kiosk and register web application built with **React (Vite)**, **Tailwind CSS**, and **Google Sheets (Google Apps Script)**.

Designed for free, instant deployment on **Vercel** with real-time status detection and zero client-side persistence (no localStorage or cookies for attendance state).

---

## 📊 Google Sheet Setup & Configuration

### 1. Create the Spreadsheet
1. Go to [Google Sheets](https://sheets.new) and create a new spreadsheet.
2. Name it: **`Employee-Attendance-Register`**.

### 2. Configure the Tabs
Ensure the spreadsheet has two tabs named exactly:

#### Tab 1: `Employees`
| Column A | Column B |
|---|---|
| **Employee Name** | **Avatar Color** |
| Alex Morgan | #4f46e5 |
| David Kim | #0ea5e9 |
| Elena Rostova | #10b981 |
| Marcus Chen | #f59e0b |
| Sophia Taylor | #ec4899 |

> 💡 **Adding or removing an employee in Tab 1 automatically updates the roster on the website!**

#### Tab 2: `Attendance_Log`
Create the header row in Row 1:
| Col A | Col B | Col C | Col D | Col E | Col F |
|---|---|---|---|---|---|
| **Name** | **Date** | **Time** | **Time In** | **Time Out** | **Hours Worked** |

---

## 🚀 Google Apps Script Deployment (`Code.gs`)

1. In your Google Sheet, click on **Extensions** > **Apps Script**.
2. Delete any boilerplate code inside `Code.gs`.
3. Copy and paste the entire contents of the `Code.gs` file from this project into the Apps Script editor.
4. Click the blue **Deploy** button at the top right > **New deployment**.
5. Click the gear icon next to "Select type" and select **Web app**.
6. Set the configuration options **strictly** as follows:
   - **Description**: `Employee Attendance Tracker API`
   - **Execute as**: `Me` (your Google Account email)
   - **Who has access**: `Anyone` *(Crucial: allows zero-login attendance without requiring Google sign-in from staff)*
7. Click **Deploy**.
8. Grant access permissions when prompted by Google:
   - Click *Authorize Access*
   - Select your account
   - Click *Advanced* > *Go to Employee-Attendance-Register (unsafe)*
   - Click *Allow*
9. Copy your **Web App URL** (format: `https://script.google.com/macros/s/AKfycb.../exec`).

---

## 🌐 Connecting with the Frontend

You can connect your Google Sheet in two simple ways:

### Option A: Via Environment Variable (for Vercel & CI/CD)
Set the environment variable in your `.env` file or in your **Vercel Project Settings**:
```env
VITE_APPS_SCRIPT_URL="https://script.google.com/macros/s/AKfycb.../exec"
```

### Option B: Directly in the Web App Interface
1. Launch the app.
2. Click the **"Sheet Connection"** or **"Setup Guide"** button in the header.
3. Paste your Web App URL into the URL input and click **Save & Test Connection**.
4. The app will immediately verify the connection and fetch live data directly from your Google Sheet.

---

## ☁️ Deploying to Vercel (Free & Instant)

1. Push your repository to **GitHub**.
2. Open your [Vercel Dashboard](https://vercel.com) and click **Add New... > Project**.
3. Import your GitHub repository.
4. Framework Preset: **Vite** (auto-detected).
5. Add the Environment Variable:
   - Key: `VITE_APPS_SCRIPT_URL`
   - Value: `https://script.google.com/macros/s/AKfycb.../exec`
6. Click **Deploy**.
7. Your app is live with SSL on your personal `.vercel.app` domain!

---

## 🛡️ Technical & Architecture Highlights

- **Zero-Login & Device Agnostic**: No credentials required. Ideal for wall-mounted tablets, reception iPads, workshop counters, or mobile staff devices.
- **No LocalStorage Dependency**: Live active clock-in/out statuses are computed on-the-fly from the `Attendance_Log` tab via `doGet()`. Every device always sees the exact same real-time state.
- **CORS Bypass**: POST punch actions use `URLSearchParams` with `Content-Type: application/x-www-form-urlencoded` and `mode: 'no-cors'` to prevent browser preflight `OPTIONS` blocks while recording punch logs reliably.
- **Smart Shift Calculation**: Clocking out automatically correlates the previous active `Time In`, calculates shift duration in hours and minutes, and populates `Time Out` and `Hours Worked`.
