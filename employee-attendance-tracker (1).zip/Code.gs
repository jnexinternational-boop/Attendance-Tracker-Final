/**
 * Google Apps Script Backend for Employee Attendance Tracker
 * 
 * SPREADSHEET CONFIGURATION:
 * Spreadsheet Name: "Employee-Attendance-Register"
 * 
 * Tab 1: "Employees"
 *   - Column A: Employee Name
 *   - Column B: Avatar Color (e.g. #4f46e5, #0ea5e9, #10b981)
 * 
 * Tab 2: "Attendance_Log"
 *   - Column A: Name
 *   - Column B: Date
 *   - Column C: Time
 *   - Column D: Time In
 *   - Column E: Time Out
 *   - Column F: Hours Worked
 * 
 * DEPLOYMENT INSTRUCTIONS:
 * 1. Open Google Sheets (create a new spreadsheet or open existing).
 * 2. Rename it "Employee-Attendance-Register" (or any name).
 * 3. Create the two tabs: "Employees" and "Attendance_Log".
 * 4. In "Employees", add Header: [Employee Name, Avatar Color] in row 1.
 * 5. In "Attendance_Log", add Header: [Name, Date, Time, Time In, Time Out, Hours Worked] in row 1.
 * 6. Go to Extensions > Apps Script.
 * 7. Replace any code in Code.gs with this complete file.
 * 8. Click "Deploy" > "New deployment".
 * 9. Click Select type (gear icon) > "Web app".
 * 10. Configure:
 *     - Description: "Employee Attendance Tracker API"
 *     - Execute as: "Me" (your Google account)
 *     - Who has access: "Anyone" (allows zero-login kiosk/app access)
 * 11. Click "Deploy", authorize access, and copy the Web App URL (ends in /exec).
 * 12. Paste the Web App URL into the Attendance Tracker application!
 */

const SPREADSHEET_NAME = "Employee-Attendance-Register";
const TAB_EMPLOYEES = "Employees";
const TAB_LOG = "Attendance_Log";

/**
 * Helper to get the target spreadsheet.
 * Supports container-bound scripts (Extensions > Apps Script)
 * as well as standalone scripts via e.parameter.sheetId or auto-discovery.
 */
function getSpreadsheet(e) {
  try {
    var active = SpreadsheetApp.getActiveSpreadsheet();
    if (active) return active;
  } catch (err) {}

  if (e && e.parameter && e.parameter.sheetId) {
    return SpreadsheetApp.openById(e.parameter.sheetId);
  }

  // Fallback: search Drive for the file by name
  var files = DriveApp.getFilesByName(SPREADSHEET_NAME);
  if (files.hasNext()) {
    return SpreadsheetApp.open(files.next());
  }

  // If still not found, create a new one automatically
  var newSheet = SpreadsheetApp.create(SPREADSHEET_NAME);
  initTabs(newSheet);
  return newSheet;
}

/**
 * Initializes tabs and headers if they do not exist.
 */
function initTabs(ss) {
  var empSheet = ss.getSheetByName(TAB_EMPLOYEES);
  if (!empSheet) {
    empSheet = ss.insertSheet(TAB_EMPLOYEES);
    empSheet.appendRow(["Employee Name", "Avatar Color"]);
    // Seed some initial demo staff if brand new
    empSheet.appendRow(["Alex Morgan", "#4f46e5"]);
    empSheet.appendRow(["David Kim", "#0ea5e9"]);
    empSheet.appendRow(["Elena Rostova", "#10b981"]);
    empSheet.appendRow(["Marcus Chen", "#f59e0b"]);
    empSheet.appendRow(["Sophia Taylor", "#ec4899"]);
  }

  var logSheet = ss.getSheetByName(TAB_LOG);
  if (!logSheet) {
    logSheet = ss.insertSheet(TAB_LOG);
    logSheet.appendRow(["Name", "Date", "Time", "Time In", "Time Out", "Hours Worked"]);
  }
}

/**
 * Handles GET requests:
 * Returns the dynamic roster from "Employees", recent logs from "Attendance_Log",
 * and calculates the real-time active clock status for every employee.
 */
function doGet(e) {
  try {
    var ss = getSpreadsheet(e);
    initTabs(ss);

    var empSheet = ss.getSheetByName(TAB_EMPLOYEES);
    var logSheet = ss.getSheetByName(TAB_LOG);

    // 1. Fetch Employees
    var empData = empSheet.getDataRange().getValues();
    var employees = [];
    // Skip header row
    for (var i = 1; i < empData.length; i++) {
      var row = empData[i];
      var name = String(row[0] || "").trim();
      var color = String(row[1] || "").trim();
      if (name) {
        employees.push({
          name: name,
          avatarColor: color || "#4f46e5"
        });
      }
    }

    // 2. Fetch Attendance Logs
    var logData = logSheet.getDataRange().getValues();
    var logs = [];
    // Map to keep track of each employee's latest punch state
    var activeStatuses = {};

    // Initialize all known employees with OUT status
    for (var k = 0; k < employees.length; k++) {
      activeStatuses[employees[k].name] = {
        status: "OUT",
        lastPunchTime: "",
        lastTimeIn: "",
        lastTimeOut: "",
        lastDate: "",
        hoursWorked: "",
        logRowIndex: -1
      };
    }

    // Read attendance log from row 1 (skipping header at row 0)
    for (var r = 1; r < logData.length; r++) {
      var logEntry = logData[r];
      var logName = String(logEntry[0] || "").trim();
      if (!logName) continue;

      var logDate = formatDateValue(logEntry[1]);
      var logTime = formatTimeValue(logEntry[2]);
      var timeIn = formatTimeValue(logEntry[3]);
      var timeOut = formatTimeValue(logEntry[4]);
      var hoursWorked = String(logEntry[5] || "").trim();

      logs.push({
        rowIndex: r + 1, // 1-indexed sheet row
        name: logName,
        date: logDate,
        time: logTime,
        timeIn: timeIn,
        timeOut: timeOut,
        hoursWorked: hoursWorked
      });

      // Update real-time status:
      // An open clock-in has Time In filled, but Time Out empty
      if (timeIn && !timeOut) {
        activeStatuses[logName] = {
          status: "IN",
          lastPunchTime: logTime,
          lastTimeIn: timeIn,
          lastTimeOut: "",
          lastDate: logDate,
          hoursWorked: "",
          logRowIndex: r + 1
        };
      } else if (timeOut) {
        // Clocked out
        activeStatuses[logName] = {
          status: "OUT",
          lastPunchTime: logTime,
          lastTimeIn: timeIn,
          lastTimeOut: timeOut,
          lastDate: logDate,
          hoursWorked: hoursWorked,
          logRowIndex: r + 1
        };
      }
    }

    var result = {
      success: true,
      spreadsheetName: ss.getName(),
      employees: employees,
      activeStatuses: activeStatuses,
      logs: logs.slice(-50).reverse(), // Send recent 50 logs, latest first
      totalLogs: logs.length,
      serverTime: new Date().toISOString()
    };

    return ContentService
      .createTextOutput(JSON.stringify(result))
      .setMimeType(ContentService.MimeType.JSON);

  } catch (error) {
    var errorResult = {
      success: false,
      error: error.toString(),
      serverTime: new Date().toISOString()
    };
    return ContentService
      .createTextOutput(JSON.stringify(errorResult))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

/**
 * Handles POST requests:
 * Receives application/x-www-form-urlencoded data from frontend.
 * 
 * Punch Logic:
 * - If Clocking In: Populates Name, Date, Time, Time In (Time Out & Hours Worked left blank).
 * - If Clocking Out: Populates Name, Date, Time, Time Out, and Hours Worked.
 *   Also updates the matching open Time In row if present, or appends.
 */
function doPost(e) {
  try {
    var ss = getSpreadsheet(e);
    initTabs(ss);
    var logSheet = ss.getSheetByName(TAB_LOG);

    var params = e.parameter || {};

    // Support raw JSON body fallback if passed as JSON
    if (e.postData && e.postData.contents && (!params.name || params.name === "")) {
      try {
        var parsed = JSON.parse(e.postData.contents);
        params = parsed;
      } catch (ex) {}
    }

    var name = String(params.name || "").trim();
    var date = String(params.date || "").trim();
    var time = String(params.time || "").trim();
    var timeIn = String(params.timeIn || "").trim();
    var timeOut = String(params.timeOut || "").trim();
    var hoursWorked = String(params.hoursWorked || "").trim();
    var action = String(params.action || params.type || "").toUpperCase();

    if (!name) {
      return ContentService
        .createTextOutput(JSON.stringify({ success: false, error: "Missing employee name" }))
        .setMimeType(ContentService.MimeType.JSON);
    }

    var now = new Date();
    if (!date) {
      date = Utilities.formatDate(now, Session.getScriptTimeZone(), "yyyy-MM-dd");
    }
    if (!time) {
      time = Utilities.formatDate(now, Session.getScriptTimeZone(), "hh:mm a");
    }

    var isClockOut = (action === "OUT" || action === "CLOCKOUT" || timeOut !== "");

    if (isClockOut) {
      // Clocking OUT
      if (!timeOut) timeOut = time;

      // Find the last open clock-in entry for this employee in Attendance_Log
      var logData = logSheet.getDataRange().getValues();
      var openRowIndex = -1;
      var foundTimeIn = "";

      for (var r = logData.length - 1; r >= 1; r--) {
        var rName = String(logData[r][0] || "").trim();
        var rTimeIn = String(logData[r][3] || "").trim();
        var rTimeOut = String(logData[r][4] || "").trim();

        if (rName.toLowerCase() === name.toLowerCase() && rTimeIn && !rTimeOut) {
          openRowIndex = r + 1; // 1-indexed for Sheet API
          foundTimeIn = rTimeIn;
          break;
        }
      }

      // If hoursWorked wasn't provided by client and we found Time In, calculate it
      if (!hoursWorked && foundTimeIn) {
        hoursWorked = calculateDuration(foundTimeIn, timeOut);
      }

      if (openRowIndex !== -1) {
        // Complete the open shift row directly:
        // Column C: Time (last activity)
        // Column E: Time Out
        // Column F: Hours Worked
        logSheet.getRange(openRowIndex, 3).setValue(time);
        logSheet.getRange(openRowIndex, 5).setValue(timeOut);
        logSheet.getRange(openRowIndex, 6).setValue(hoursWorked || "");

        var respObj = {
          success: true,
          message: "Clock out recorded for " + name,
          updatedRow: openRowIndex,
          name: name,
          timeIn: foundTimeIn,
          timeOut: timeOut,
          hoursWorked: hoursWorked
        };
        return ContentService
          .createTextOutput(JSON.stringify(respObj))
          .setMimeType(ContentService.MimeType.JSON);
      } else {
        // If no open row found, append a new row recording the clock out
        logSheet.appendRow([name, date, time, timeIn || "", timeOut, hoursWorked || ""]);
        return ContentService
          .createTextOutput(JSON.stringify({
            success: true,
            message: "Clock out appended for " + name,
            name: name,
            timeOut: timeOut,
            hoursWorked: hoursWorked
          }))
          .setMimeType(ContentService.MimeType.JSON);
      }

    } else {
      // Clocking IN
      if (!timeIn) timeIn = time;
      // Per specification: Populates Name, Date, Time, and Time In (Time Out and Hours Worked left blank)
      logSheet.appendRow([name, date, time, timeIn, "", ""]);

      return ContentService
        .createTextOutput(JSON.stringify({
          success: true,
          message: "Clock in recorded for " + name,
          name: name,
          timeIn: timeIn
        }))
        .setMimeType(ContentService.MimeType.JSON);
    }

  } catch (error) {
    return ContentService
      .createTextOutput(JSON.stringify({ success: false, error: error.toString() }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

/**
 * Calculates duration string (e.g. "8.2 hrs" or "7h 45m") from time strings.
 */
function calculateDuration(inStr, outStr) {
  try {
    var parseTime = function(tStr) {
      var d = new Date();
      var match = tStr.match(/(\d+):(\d+)(?::(\d+))?\s*(AM|PM)?/i);
      if (!match) return null;
      var hours = parseInt(match[1], 10);
      var minutes = parseInt(match[2], 10);
      var ampm = match[4];
      if (ampm) {
        ampm = ampm.toUpperCase();
        if (ampm === "PM" && hours < 12) hours += 12;
        if (ampm === "AM" && hours === 12) hours = 0;
      }
      d.setHours(hours, minutes, 0, 0);
      return d;
    };

    var inTime = parseTime(inStr);
    var outTime = parseTime(outStr);
    if (!inTime || !outTime) return "";

    var diffMs = outTime.getTime() - inTime.getTime();
    if (diffMs < 0) {
      // Next day overnight shift
      diffMs += 24 * 60 * 60 * 1000;
    }

    var totalMinutes = Math.round(diffMs / 60000);
    var hours = Math.floor(totalMinutes / 60);
    var mins = totalMinutes % 60;

    var decimalHours = (diffMs / (1000 * 60 * 60)).toFixed(2);
    return decimalHours + " hrs (" + hours + "h " + mins + "m)";
  } catch (e) {
    return "";
  }
}

function formatDateValue(val) {
  if (!val) return "";
  if (val instanceof Date) {
    return Utilities.formatDate(val, Session.getScriptTimeZone(), "yyyy-MM-dd");
  }
  return String(val);
}

function formatTimeValue(val) {
  if (!val) return "";
  if (val instanceof Date) {
    return Utilities.formatDate(val, Session.getScriptTimeZone(), "hh:mm a");
  }
  return String(val);
}
